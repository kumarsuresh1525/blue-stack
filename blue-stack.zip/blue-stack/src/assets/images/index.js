import {ReactComponent as Price} from './price.png';

export {Price};